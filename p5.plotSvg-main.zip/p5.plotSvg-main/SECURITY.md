# Security Policy

## Supported Versions

The following versions of this project would be supported with security updates if any were necessary.

| Version | Supported          |
| ------- | ------------------ |
| 0.1.x   | :white_check_mark: |

## Reporting a Vulnerability

I can't imagine how there would be a security vulnerability with this project, but if you find one, please file an issue or otherwise notify @golanlevin.
