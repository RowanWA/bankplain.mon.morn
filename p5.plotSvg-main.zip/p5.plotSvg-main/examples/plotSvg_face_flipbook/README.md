# plotSvg_face_flipbook Example

![plotSvg_face_flipbook.gif](plotSvg_face_flipbook.gif)

This example exports a tiny flipbook, using faces recording from Google's MediaPipe face-tracker. Code is available:

* [here](sketch.js)
* [@openProcessing](https://openprocessing.org/sketch/2488219)